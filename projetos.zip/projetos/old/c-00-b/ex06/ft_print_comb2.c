/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adsorodr <adsorodr@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/15 16:50:43 by adsorodr          #+#    #+#             */
/*   Updated: 2024/07/16 16:56:18 by adsorodr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_number(int number_lt_100)
{
	char	d;
	char	u;

	d = (number_lt_100 / 10) + 48;
	u = (number_lt_100 % 10) + 48;
	write(1, &d, 1);
	write(1, &u, 1);
}

void	print_separator(int n_one, int n_two)
{
	if (!((n_one == 98) && (n_two == 99)))
	{
		write(1, ", ", 2);
	}
}

void	ft_print_comb2(void)
{
	int	n_one;
	int	n_two;

	n_one = 0;
	n_two = 0;
	while (n_one < 100)
	{
		n_two = n_one + 1;
		while (n_two < 100)
		{
			ft_print_number(n_one);
			write(1, " ", 1);
			ft_print_number(n_two);
			print_separator(n_one, n_two);
			n_two++;
		}
		n_one++;
	}
}
