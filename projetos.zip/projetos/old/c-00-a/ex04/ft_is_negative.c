/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adsorodr <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 15:16:03 by adsorodr          #+#    #+#             */
/*   Updated: 2024/07/13 15:34:15 by adsorodr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_is_negative(int n)
{
	char	character_to_print;

	if (n < 0)
	{
		character_to_print = 'N';
	}
	else
	{
		character_to_print = 'P';
	}
	write(1, &character_to_print, 1);
}
