#!/bin/sh
basename -s .sh -a $(find . -type f -name '*.sh' | tr '\n' ' ')