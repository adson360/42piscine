/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adsorodr <adsorodr@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/19 14:53:59 by adsorodr          #+#    #+#             */
/*   Updated: 2024/07/19 15:52:10 by adsorodr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int	temp;
	int	i;
	int	j;

	i = 0;
	while (i < size -1)
	{
		j = 0;
		while (j < ((size - 1) - i))
		{
			if (tab[j] > tab[(j + 1)])
			{
				temp = tab[j];
				tab[j] = tab[(j + 1)];
				tab[(j + 1)] = temp;
			}
			j++;
		}
		i++;
	}
}
