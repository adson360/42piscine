#!/bin/sh
git log --pretty=tformat:'%H' -n5