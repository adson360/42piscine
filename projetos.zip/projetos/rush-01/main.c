/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adsorodr <adsorodr@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/22 11:17:18 by adsorodr          #+#    #+#             */
/*   Updated: 2024/07/22 11:45:10 by adsorodr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
void	ft_putstr(char *str);

char *make_hello(void)
{
	char *oi;

	oi = NULL;
	oi = malloc(4 * sizeof(char));
	if (oi == NULL)
	{
		ft_putstr("out of memory\n");
		return(1)
	}
	oi[0] = 'o';
	oi[1] = 'i';
	oi[2] = '\n';
	oi[3] = '\0';
	return (oi);
}
/*
int main(void)
{
	char *hello;
	
	hello = make_hello();
	ft_putstr(hello);
	free(hello);


}
*/

#include <stdio.h>

int main(void)
{
	/*char array1[16];
	char array2[12489];*/
	char array1[] = "hello";
	char array2[] = "jsafiojsaiojdaiodjsioadjasiojdsioajdosiajd";

	array[numero];//nao

	array = malloc(sizeof(x) * numero); //sim

	int size1;
	int size2;

	size1 = sizeof(char);
	size2 = sizeof(int);

	printf("size1 %i\n", size1);
	printf("size2 %i\n", size2);

	if (size1 != size2)
	{
		ft_putstr("é diferente");
	}
	else
	{
		ft_putstr("é igual");
	}
}
