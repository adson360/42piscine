#include <stdio.h>

int ft_puterror(void);
int	ft_str_is_numeric_btw_1_4(char *str);

int* make_matrix(void)
{
	int* input;

	input = malloc(16 * sizeof(int));
	return (input);
}

int	main(int argc, char **argv)
{
	int	i;
	int	number;
	// int	pohib[16];
//	int	input[16];
	int* input;
	
	char c;
	if (argc != 2)
	{
		return (ft_puterror());
	}

	if (argc == 2)
	{
		i = 0;
		while (i < 31)
		{
			c = argv[1][i];
			if (ft_str_is_numeric_btw_1_4(c))
			{
				c = '1';
				number = c - '0';
				input[i / 2] = number;
			}
			i+=2;
		}
	}
}
