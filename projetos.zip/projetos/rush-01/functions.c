/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   functions.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adsorodr <adsorodr@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/22 10:59:55 by adsorodr          #+#    #+#             */
/*   Updated: 2024/07/22 10:59:58 by adsorodr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar(str[i]);
		i++;
	}
}

int	ft_puterror(void)
{
	ft_putstr("Error\n");
	return (1);
}

int	ft_str_is_numeric_btw_1_4(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!((str[i] >= '1') && (str[i] <= '4')))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
