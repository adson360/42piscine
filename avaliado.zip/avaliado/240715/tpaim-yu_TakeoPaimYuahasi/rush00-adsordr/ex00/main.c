/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adsorodr <adsorodr@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/12 21:24:15 by adsorodr          #+#    #+#             */
/*   Updated: 2024/07/15 14:22:50 by adsorodr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <string.h>

// void	rush(int x, int y);

int	main(int argc, char **argv)
{
	int	i;

	printf("Argc: %d\n", argc);
	i = 0;
	while (argv[i])
	{
		write(1, "Argv: ", strlen("Argv: "));
		write(1, argv[i], strlen(argv[i]));
		write(1, "\n", 1);
		i++;
	}
	// rush(5, 5);
	// rush(1, 1);
	// rush(0, 0);
	return (0);
}
